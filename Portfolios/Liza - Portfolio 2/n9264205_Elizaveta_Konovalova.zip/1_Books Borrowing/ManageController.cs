 //
        //GET: /Manage/ViewMyBooksBorrowed/
        public ActionResult ViewMyBooksBorrowed()
        {
            string currentLoggedInUser = null;
            if (ClaimsPrincipal.Current.Identity.IsAuthenticated)
                currentLoggedInUser = ClaimsPrincipal.Current.Identity.Name;

            var books = (from book in db.Books
                         where book.Owner == currentLoggedInUser && book.BrwdBy != null
                         select new ViewMyBooks
                         {
                             Author = book.Author,
                             BookTitle = book.Title,
                             Edition = book.Edition,
                             ISBN = book.ISBN,
                             Year = book.Year,
                             B_ID = book.B_ID,
                             Borrower = book.BrwdBy
                         }).AsEnumerable();

            ViewMyBooks model = new ViewMyBooks
            {
                BookDetails = books
            };

            return View(model);
        }

                //
        //POST: Manage/RequestsToBorrow/
        [HttpPost]
        public ActionResult RequestsToBorrow(string responce, int bookValue, string borrower, int requestID)
        {
            //Get borrower information of the book from the database.
            AspNetUser borrow = db.AspNetUsers.Where(x => x.UserName == borrower)
                .Select(x => x).FirstOrDefault();

            if (true)
            {

                if (responce.Equals("Rate"))
                {
                    setRequestID(requestID);

                    return RedirectToAction("PublicProfile", "Account", new
                    {
                        username = borrow.UserName,
                        emailsent = "",
                        returnedBorrower = true,
                        bookID = 0
                    });
                }
                else
                {

                    Email confirmation = new Email();
                    shared = new SharedMethods();
                    AccountController account = new AccountController();

                    //Find requested book in the database.
                    var results = db.Books.Find(bookValue);

                    //Get owner information of the book from the database.
                    AspNetUser owner = db.AspNetUsers.Where(x => x.UserName == results.Owner)
                        .Select(x => x).FirstOrDefault();

                    switch (responce)
                    {
                        case "Accept":
                            //Assign book's borrower
                            results.BrwdBy = borrower;
                            db.SaveChanges();

                            //Create message body for request reply on a successful application.
                            confirmation.message = "Hello " + borrow.FirstName + " " + borrow.LastName +
                                ",<br /><br/> You have recently sent a request to " + owner.FirstName +
                                " " + owner.LastName + " to borrow this book:<br/><br/><b>Title</b>:" + results.Title + "<br/><b>Author</b>: "
                                + results.Author + "<br/><b>Year:</b> " + results.Year +
                                "<br/><br/>Congratulations! Your request has been <b>accepted</b>"
                                + "<br/><br/>Enjoy the book!<br/>Kind regards,<br/><b>Texchange</b>.";

                            //Increase number of tokens of the book's owner.
                            account.incrementTokens(owner.Id);

                            //Decrease number of tokens the book's borrower.
                            account.decrementTokens(borrow.Id);

                            if (owner.Notified >= 1)
                            {
                                //Decrease owner's number of notifications sent.
                                owner.Notified -= 1;
                            }
                            break;
                        case "Decline":
                            //Create message body for request reply on an unsuccessful application.
                            confirmation.message = "Hello " + borrow.FirstName + " " + borrow.LastName
                                + ",<br /><br/> You have recently sent a request to " + owner.FirstName + " " + owner.LastName
                                + " to borrow this book:<br/><br/><b>Title</b>:" + results.Title + "<br/><b>Author</b>: "
                                + results.Author + "<br/><b>Year:</b> " + results.Year +
                                "<br/><br/>We are sorry, but your request was <b>rejected</b><br/><br/>Good luck!<br/>Kind regards,<br/>"
                                + "<b>Texchange</b>.";
                            break;
                    }

                    confirmation.fromAddress = owner.Email;
                    confirmation.fromName = owner.FirstName;
                    confirmation.toAddress = borrow.Email;
                    confirmation.toName = borrow.FirstName;
                    confirmation.subject = "Texchange: Book request confirmation";

                    //Send request reply to the borrower.
                    shared.SendEmailMessage(confirmation);

                    //Find this request in the database.
                    var requests = db.Requests.Find(requestID);

                    if (requests != null)
                    {
                        //Remove the found request from the database.
                        db.Requests.Remove(requests);
                        db.SaveChanges();
                    }

                    return Redirect("../Manage/RequestsToBorrow");
                }
            }
            else 
            {
                return Redirect("../Manage/RequestsToBorrow");
            }
        }