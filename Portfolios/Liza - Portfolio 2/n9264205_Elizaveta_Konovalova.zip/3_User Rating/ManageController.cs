        private void setRequestID(int id)
        {
            requestID = id;
        }

        private int getRequestID()
        {
            return requestID;
        }

        public ActionResult RateBorrower(int id, bool rated)
        {
            if (id == 0)
            {
                var requests = db.Requests.Find(getRequestID());

                if (requests != null)
                {
                    //Remove the found request from the database.
                    db.Requests.Remove(requests);
                    db.SaveChanges();
                }

                return Redirect("../RequestsToBorrow");
            }

            else
            {
                var bookS = db.Books.Find(id);
                int rid = RateLoaner(bookS);
                setRequestID(rid);
                ViewMyBooksBorrower(id, rated);
                return Redirect("../ViewMyBooksBorrower");
            }
        }

        //Sends requests to a loaner to rate a borrower.
        public int RateLoaner( Book book)
        {
            shared = new SharedMethods();
            Request request = new Request();
            //Get owner information of the book from the database.
            AspNetUser owner = db.AspNetUsers.Where(x => x.UserName == book.Owner)
                .Select(x => x).FirstOrDefault();

            //Get borrower information of the book from the database.
            AspNetUser borrow = db.AspNetUsers.Where(x => x.UserName == book.BrwdBy)
                .Select(x => x).FirstOrDefault();

            request = shared.SendRequest(borrow.UserName, owner.Id, "Please, rate "+borrow.FirstName+"!", 0);

            int requestID = request.Id;

            return requestID;
        }

         //
        //POST: Manage/RequestsToBorrow/
        [HttpPost]
        public ActionResult RequestsToBorrow(string responce, int bookValue, string borrower, int requestID)
        {
            //Get borrower information of the book from the database.
            AspNetUser borrow = db.AspNetUsers.Where(x => x.UserName == borrower)
                .Select(x => x).FirstOrDefault();

            if (true)
            {

                if (responce.Equals("Rate"))
                {
                    setRequestID(requestID);

                    return RedirectToAction("PublicProfile", "Account", new
                    {
                        username = borrow.UserName,
                        emailsent = "",
                        returnedBorrower = true,
                        bookID = 0
                    });
                }
                ..........................................
                More code after refer to Books Borrowing section