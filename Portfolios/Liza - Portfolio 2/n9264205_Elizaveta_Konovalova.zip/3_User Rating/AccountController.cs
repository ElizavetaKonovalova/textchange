               //
        // GET: /Account/PublicProfile
        [HttpGet]
        [AllowAnonymous]
        public ActionResult PublicProfile(string username, string emailsent, bool returnedBorrower, int bookID)
        {
            code before
            ...................
                if (returnedBorrower == true)
                {
                    result.returned = true;
                    result.bookID = bookID;
                }

                    var allComments = db.Comments.Where(x => x.Receiver.Equals(result.targetUser.UserName)).Select(x =>
                        new Commenting { Comment = x.CommentText, Date = x.Date.ToString(), Sender = x.Sender }).ToList();

                    if (allComments.Count == 0)
                    {
                        Commenting comments = new Commenting
                        {
                            Comment = "There are currently no comments....",
                            Date = "",
                            Sender=""
                        };

                        allComments.Add(comments);
                    }

                    result.AllComments = allComments;
                    // If we've already tried to send a contact email, save this into 
                    // the model so the view can display an appropriate message
                    switch (emailsent)
                    {
                        case "success":
                            result.contactEmail = new Email();
                            result.contactEmail.success = true;
                            break;
                        case "error":
                            result.contactEmail = new Email();
                            result.contactEmail.success = false;
                            break;
                        case "youself":
                            result.contactEmail = new Email();
                            result.contactEmail.success = false;
                            ModelState.AddModelError("", "Test Success!");
                            break;
                        default:
                            break;
                    }
                    ..................
                    code after
        }
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PublicProfile(string userId, string thumbs, int bookId)
        {
            bool ratedBook = false;

            AspNetUser user = db.AspNetUsers.Find(userId);
            if (!User.Identity.Name.Equals(user.UserName))
            {
                switch (thumbs)
                {
                    case "ThumbsUp":
                        user.ThumbsUp += 1;
                        break;
                    case "ThumbsDown":
                        user.ThumbsDown += 1;
                        break;
                    default:
                        break;
                }

                ratedBook = true;
                db.SaveChanges();
            }

            if (ratedBook == true)
            {
                return RedirectToAction("RateBorrower", "Manage", new { id = bookId, rated = ratedBook });
            }
            else
            {
                return RedirectToAction("PublicProfile", "Account", new { username = user.UserName, emailsent = "", 
                    returnedBorrower = true, bookID = bookId });
            }
        }

       public ActionResult LeaveAComment(PublicProfileViewModel model,string fromUser, string toUsername, int bookID )
        {
            string senderFirstName = db.AspNetUsers.Where(x => x.UserName.Equals(fromUser)).Select(x => x.FirstName).FirstOrDefault();
            string senderLastName = db.AspNetUsers.Where(x => x.UserName.Equals(fromUser)).Select(x => x.LastName).FirstOrDefault();
            Comment userComment = new Comment();
            userComment.CommentText = model.comment;
            userComment.Date = DateTime.Now;
            userComment.Sender = senderFirstName + " "+senderLastName;
            userComment.Receiver = toUsername;
            db.Comments.Add(userComment);
            db.SaveChanges();

            return RedirectToAction("PublicProfile", "Account", new { username = toUsername, emailsent = "", returnedBorrower = true, bookId = bookID });
        }