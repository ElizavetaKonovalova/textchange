        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Book book = db.Books.Find(id);
            if (book.BrwdBy.Equals(null))
            {
                db.Books.Remove(book);
                db.SaveChanges();
            }
            
            return RedirectToAction("../Manage/ViewMyBooks");
        }