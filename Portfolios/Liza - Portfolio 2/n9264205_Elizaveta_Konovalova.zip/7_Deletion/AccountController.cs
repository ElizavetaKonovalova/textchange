
        private bool Delete(string userName)
        {
            bool deleted = false;

            var findUser = db.AspNetUsers.Where(x=>x.UserName.Equals(userName)).Select(x=>x).FirstOrDefault();
            var findUploadedBook = db.Books.Where(x => x.Owner.Equals(userName)).Select(x => x).ToList();
            var findBorrowedBook = db.Books.Where(x => x.BrwdBy.Equals(userName)).Select(x => x).ToList();

            if (!findUser.UserName.Equals("ifb299books"))
            {
                if (findUploadedBook.Count == 0)
                {
                    if (findBorrowedBook.Count == 0)
                    {
                        var deleteComments = db.Comments.Where(x => x.Receiver.Equals(findUser.UserName)).Select(x=>x).ToList();
                        foreach (var comment in deleteComments)
                        {
                            db.Comments.Remove(comment);
                        }

                        var deleteRequests = db.Requests.Where(x => x.UserID.Equals(findUser.UserName)).Select(x => x).ToList();
                        foreach (var request in deleteRequests)
                        {
                            db.Requests.Remove(request);
                        }

                        db.AspNetUsers.Remove(findUser);
                        db.SaveChanges();
                        deleted = true;
                    }
                }
            }
            return deleted;
        }

        public ActionResult DeleteAccount(string userName)
        {
            if (Delete(userName))
            {
                LogOff();
            }
            
            return Redirect("../Home/Index");
        }