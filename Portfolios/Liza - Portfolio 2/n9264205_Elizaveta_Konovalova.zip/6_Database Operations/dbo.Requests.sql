﻿CREATE TABLE [dbo].[Requests] (
    [Id]          INT            IDENTITY (1, 1) NOT NULL,
    [UserID]      NVARCHAR (MAX) NOT NULL,
    [RequestFrom] NVARCHAR (MAX) NOT NULL,
    [RequestText] NVARCHAR (MAX) NOT NULL,
    [BookId]      INT            DEFAULT ((0)) NOT NULL,
    [Status ]     NVARCHAR (50)  NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

