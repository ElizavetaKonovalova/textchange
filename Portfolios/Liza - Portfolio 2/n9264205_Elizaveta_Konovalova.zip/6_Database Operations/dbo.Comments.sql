﻿CREATE TABLE [dbo].[Comments] (
    [Id]          INT            NOT NULL IDENTITY,
    [CommentText] NVARCHAR (MAX) NOT NULL,
    [Sender]      NVARCHAR (MAX) NOT NULL,
    [Date]        DATETIME       NOT NULL,
    [Receiver]    NVARCHAR (MAX) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

