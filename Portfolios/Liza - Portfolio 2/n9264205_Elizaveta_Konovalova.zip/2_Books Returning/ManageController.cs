        
        //
        //GET: /Manage/ViewMyBooksBorrower/
        [HttpGet]
        public ActionResult ViewMyBooksBorrower()
        {
            string currentLoggedInUser = null;
            if (ClaimsPrincipal.Current.Identity.IsAuthenticated)
                currentLoggedInUser = ClaimsPrincipal.Current.Identity.Name;

            return View(getBorrowed(currentLoggedInUser));
        }

        private ViewMyBooks getBorrowed(string user)
        {
            var books = (from book in db.Books
                         where book.BrwdBy == user
                         select new ViewMyBooks
                         {
                             Author = book.Author,
                             BookTitle = book.Title,
                             Edition = book.Edition,
                             ISBN = book.ISBN,
                             Year = book.Year,
                             B_ID = book.B_ID,
                             Borrower = book.BrwdBy
                         }).AsEnumerable();

            AspNetUser target = db.AspNetUsers.Where(x=>x.UserName == user).Select(x=>x).FirstOrDefault();

            ViewMyBooks model = new ViewMyBooks
            {
                BookDetails = books,
                targetUser = target
            };

            return model;
        }

        //
        //POST: /Manage/ViewMyBooksBorrower/
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ViewMyBooksBorrower(int id, bool rated)
        {
            string currentLoggedInUser = null;
            if (ClaimsPrincipal.Current.Identity.IsAuthenticated)
                currentLoggedInUser = ClaimsPrincipal.Current.Identity.Name;

            var book = db.Books.Find(id);

            //Get owner information of the book from the database.
            AspNetUser owner = db.AspNetUsers.Where(x => x.UserName == book.Owner )
                .Select(x => x).FirstOrDefault();

            //Get borrower information of the book from the database.
            AspNetUser borrow = db.AspNetUsers.Where(x => x.UserName == book.BrwdBy)
                .Select(x => x).FirstOrDefault();

            if(rated == true)
            {
                Email confirmation = new Email();
                shared = new SharedMethods();
                AccountController account = new AccountController();

                confirmation.fromAddress = borrow.Email;
                confirmation.fromName = borrow.FirstName;
                confirmation.toAddress = owner.Email;
                confirmation.toName = owner.FirstName;
                confirmation.subject = "Texchange: Book returned";

                if (book.BrwdBy.Equals(currentLoggedInUser))
                {
                    book.BrwdBy = null;
                    db.SaveChanges();
                }

                confirmation.message = "Hello " + owner.FirstName + " " + owner.LastName
                + ",<br /><br/> Your book has been returned by " + borrow.FirstName + " " + borrow.LastName
                + "  :<br/><br/><b>Title:</b> " + book.Title + "<br/><b>Author</b>: "
                + book.Author + "<br/><b>Year:</b> " + book.Year + "<br/><br/>Do you think there was a <b>mistake</b>??<br/>" +
                "Contact admin ifb299books@gmail.com <br/><br/>Kind regards,<br/><b>Texchange</b>.";

                //Send request reply to the borrower.
                bool sent = shared.SendEmailMessage(confirmation);

                if (sent)
                {
                    return RedirectToAction("ViewMyBooksBorrower");
                }
            }

            return RedirectToAction("PublicProfile", "Account", new { 
                username = owner.UserName, emailsent = "", returnedBorrower = true, bookId = book.B_ID });
        }

